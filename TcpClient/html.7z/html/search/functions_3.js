var searchData=
[
  ['errornickname',['errorNickName',['../class_main_window.html#a11974cf1876bbfb8d7ff9fdc56efff06',1,'MainWindow']]]
];
