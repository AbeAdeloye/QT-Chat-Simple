var searchData=
[
  ['datalengthforcurrentdatatype',['dataLengthForCurrentDataType',['../class_connection.html#a48f4fbdb292a33b1242652fcaa70ffec',1,'Connection']]],
  ['deletediscnocteduser',['deleteDiscnoctedUser',['../class_main_window.html#af98dfe95f9c6c184409a127a551b059a',1,'MainWindow']]],
  ['deleteuseratlistview',['deleteUserAtListView',['../class_main_window.html#a8a719c9b0ced50380d58cfa2845b7633',1,'MainWindow']]],
  ['disconnecteduser',['disconnectedUser',['../class_connection.html#aa64cb77206e3d637e893cf835fac7f45',1,'Connection']]]
];
