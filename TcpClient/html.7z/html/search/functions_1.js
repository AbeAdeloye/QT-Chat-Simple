var searchData=
[
  ['changeevent',['changeEvent',['../class_main_window.html#af4ca5d0d3d18ddcb7d54b6596bbf4797',1,'MainWindow']]],
  ['configs',['Configs',['../class_configs.html#a051e49766fce6c6016916d9805edd0b6',1,'Configs']]],
  ['connection',['Connection',['../class_connection.html#a903238da767af13261c8de1721807b48',1,'Connection']]],
  ['createconnections',['createConnections',['../class_main_window.html#af773488e0b16efe6c0fc67ad348b86b2',1,'MainWindow']]]
];
