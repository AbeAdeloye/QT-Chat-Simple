var searchData=
[
  ['main',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2ecpp',['mainwindow.cpp',['../mainwindow_8cpp.html',1,'']]],
  ['mainwindow_2eh',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['maxbuffersize',['MaxBufferSize',['../connection_8h.html#a97a33a33e5428e13cfa0eff5ba0e846f',1,'connection.h']]],
  ['message',['Message',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620ac67066301d74bfff626f65f1e71b367e',1,'DataType']]]
];
