var searchData=
[
  ['processdata',['processData',['../class_connection.html#aa7071a2d55cdf43ffe4b02b3c7203a04',1,'Connection']]],
  ['processerror',['processError',['../class_connection.html#aacc0c308caecfacb1411d6f454b88cf2',1,'Connection']]],
  ['processreadyread',['processReadyRead',['../class_connection.html#af05263c69e7d418695086a038a16493b',1,'Connection']]]
];
