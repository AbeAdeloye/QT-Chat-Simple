var searchData=
[
  ['s_5fpinstance',['s_pInstance',['../class_singleton.html#a33dd2aff9e6ec0f9e6d77088707a3474',1,'Singleton']]],
  ['separator',['Separator',['../connection_8cpp.html#a1e155da77695c2b37ef870c9df99a52f',1,'connection.cpp']]]
];
