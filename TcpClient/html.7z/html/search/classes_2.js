var searchData=
[
  ['singleton',['Singleton',['../class_singleton.html',1,'']]],
  ['singleton_3c_20configs_20_3e',['Singleton&lt; Configs &gt;',['../class_singleton.html',1,'']]],
  ['singleton_3c_20connection_20_3e',['Singleton&lt; Connection &gt;',['../class_singleton.html',1,'']]]
];
