var searchData=
[
  ['readme',['ReadMe',['../md__read_me.html',1,'']]],
  ['readconfigs',['readConfigs',['../class_configs.html#acd646b1d8deb433e908d9c41d028e66b',1,'Configs']]],
  ['readdataintobuffer',['readDataIntoBuffer',['../class_connection.html#abbf441e943817829226fef26e741e78a',1,'Connection']]],
  ['readextradata',['readExtraData',['../class_connection.html#a3cb0816f9abeb326d7c75215cca52fb7',1,'Connection']]],
  ['readinggreeting',['ReadingGreeting',['../namespace_connected_state.html#a6544179e70d5e26fdad55409dfb143a7a675460499528aa5e48b3dc3f74e4df68',1,'ConnectedState']]],
  ['readme_2emd',['ReadMe.md',['../_read_me_8md.html',1,'']]],
  ['readprotocolheader',['readProtocolHeader',['../class_connection.html#a82ef36aa710511384c4aac47fa72e712',1,'Connection']]],
  ['readyforuse',['readyForUse',['../class_connection.html#acef3ed5d082edcef31e81dabea736185',1,'Connection::readyForUse()'],['../namespace_connected_state.html#a6544179e70d5e26fdad55409dfb143a7aa64a103952ccdd508351ba5843db4fef',1,'ConnectedState::ReadyForUse()']]],
  ['repeateduser',['RepeatedUser',['../namespace_error_type.html#a248cd0da53dab80e9a4bada192c0b669a1248d388b29c1cdaed892e5caeb4e57d',1,'ErrorType']]],
  ['repeatnickname',['repeatNickName',['../class_connection.html#a7c95d5b395dc3e5d1ef0cff9cd2072df',1,'Connection']]],
  ['reread',['reRead',['../class_configs.html#a354f25e07a37f002a6f7651ad3c5f255',1,'Configs']]]
];
