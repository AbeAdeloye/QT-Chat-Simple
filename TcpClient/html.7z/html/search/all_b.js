var searchData=
[
  ['namespaces_2eh',['namespaces.h',['../namespaces_8h.html',1,'']]],
  ['newmessage',['newMessage',['../class_connection.html#a24edb8f0db5f44e30808fac5daa0cf59',1,'Connection']]],
  ['newmssg',['newMssg',['../class_main_window.html#aa7eb693783225376bf2cbcdfc9cac528',1,'MainWindow']]],
  ['newuser',['newUser',['../class_connection.html#a97ee87f67f206ad1ee3529665223ee92',1,'Connection::newUser()'],['../class_main_window.html#acd8010859479708c2517c7f6bc1e63b9',1,'MainWindow::newUser()']]],
  ['nick',['Nick',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620aeae355ff7a3e6e1bac557639f9e0192e',1,'DataType']]],
  ['nickname',['nickName',['../class_configs.html#ae80645f7d34bee09945af2827c60ca39',1,'Configs']]]
];
