var searchData=
[
  ['_5fbuffer',['_buffer',['../class_connection.html#ad48f0a55e62d04ffe79fee19a4c6a898',1,'Connection']]],
  ['_5fcurrentdatatype',['_currentDataType',['../class_connection.html#ad1108d550e0d1c8353384de57f54fb39',1,'Connection']]],
  ['_5fextradata',['_extraData',['../class_connection.html#a5421b25e998cbcd6c9d6997652702669',1,'Connection']]],
  ['_5fisgreetingmessagesent',['_isGreetingMessageSent',['../class_connection.html#a4b656d29048156b4addfc15931fea583',1,'Connection']]],
  ['_5fisreaded',['_isReaded',['../class_configs.html#a707a65405479287e850663ece0fde748',1,'Configs']]],
  ['_5fisserverfound',['_isServerFound',['../class_connection.html#a0e880bb2e56ac9fa79acaf5a0a6f942a',1,'Connection']]],
  ['_5flistmodelusers',['_listModelUsers',['../class_main_window.html#ab6a08c24ce7007e220ace25281084a1c',1,'MainWindow']]],
  ['_5fmodelusers',['_modelUsers',['../class_main_window.html#aafed4736d1df63f79411eb305292b5f9',1,'MainWindow']]],
  ['_5fnickname',['_nickName',['../class_configs.html#ae2ae792eef374c37e37114bfc884b164',1,'Configs']]],
  ['_5fnumbytesforcurrentdatatype',['_numBytesForCurrentDataType',['../class_connection.html#ad9ae4cb31cc4a213148e45b594cefe2a',1,'Connection']]],
  ['_5fpingtimer',['_pingTimer',['../class_connection.html#a35e8f8d2ec57efdae0766b0770df500d',1,'Connection']]],
  ['_5fpongtime',['_pongTime',['../class_connection.html#a48e51c517628da72ec86220616022570',1,'Connection']]],
  ['_5fserverip',['_serverIp',['../class_configs.html#abea779eae9886d3fc0f98a98346a2f89',1,'Configs']]],
  ['_5fserverport',['_serverPort',['../class_configs.html#ada7461e6f34cffc6d7e6242600e68eaf',1,'Configs']]],
  ['_5fuserchatwindow',['_userChatWindow',['../class_main_window.html#a75c7138621d144cb562ed3f6647110a4',1,'MainWindow']]]
];
