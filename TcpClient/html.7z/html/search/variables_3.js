var searchData=
[
  ['pinginterval',['PingInterval',['../connection_8cpp.html#ad8e280fdd9867fd8915dd7e4fafbe291',1,'connection.cpp']]],
  ['pingrandomvalue',['PingRandomValue',['../connection_8cpp.html#a79e9d2c9fd17b5b5e4b833024bc0583c',1,'connection.cpp']]],
  ['ponginterval',['PongInterval',['../connection_8cpp.html#a162a8bfadf8d03ffb88e49d2f13220f8',1,'connection.cpp']]]
];
