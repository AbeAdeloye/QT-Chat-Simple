var searchData=
[
  ['s_5fpinstance',['s_pInstance',['../class_singleton.html#a33dd2aff9e6ec0f9e6d77088707a3474',1,'Singleton']]],
  ['sendgreetingmessage',['sendGreetingMessage',['../class_connection.html#af9c4d241f6845701c8ea393ee59e06cb',1,'Connection']]],
  ['sendmessage',['sendMessage',['../class_connection.html#a4f5f635d3584775de12d009bbc5a6924',1,'Connection::sendMessage()'],['../class_main_window.html#a17c431be33f2b2b07f0994c549913b95',1,'MainWindow::sendMessage()']]],
  ['sendping',['sendPing',['../class_connection.html#a8f9b99bbea1f88aca4ffecc3efc9ce2f',1,'Connection']]],
  ['separator',['Separator',['../connection_8cpp.html#a1e155da77695c2b37ef870c9df99a52f',1,'connection.cpp']]],
  ['serverip',['serverIp',['../class_configs.html#a9cda9e0f301451ed7dcf2661966109c6',1,'Configs']]],
  ['serverisconnected',['serverIsConnected',['../class_connection.html#a748f39d7d43043639e1a5c3d60e36cb3',1,'Connection']]],
  ['serverport',['serverPort',['../class_configs.html#ac275f4b2f75f4a0da63057e7edc40167',1,'Configs']]],
  ['singleton',['Singleton',['../class_singleton.html',1,'Singleton&lt; T &gt;'],['../class_singleton.html#ab5f94d8f7b42c3fbc3a41335ffa583de',1,'Singleton::Singleton()']]],
  ['singleton_2eh',['singleton.h',['../singleton_8h.html',1,'']]],
  ['singleton_3c_20configs_20_3e',['Singleton&lt; Configs &gt;',['../class_singleton.html',1,'']]],
  ['singleton_3c_20connection_20_3e',['Singleton&lt; Connection &gt;',['../class_singleton.html',1,'']]],
  ['stoptryconnect',['stopTryConnect',['../class_connection.html#a1fd6f3bd9e2a039f88d6285bff257078',1,'Connection']]]
];
