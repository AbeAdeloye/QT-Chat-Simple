var searchData=
[
  ['greetingmessage',['greetingMessage',['../class_connection.html#a2bde03d6d75d386f1219ed3e96fa833f',1,'Connection']]]
];
