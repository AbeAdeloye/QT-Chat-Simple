var searchData=
[
  ['greeting',['Greeting',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620a0819a4a3ceb1c5efdb8f8057db415035',1,'DataType']]],
  ['greetingmessage',['greetingMessage',['../class_connection.html#a2bde03d6d75d386f1219ed3e96fa833f',1,'Connection']]]
];
