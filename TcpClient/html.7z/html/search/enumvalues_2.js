var searchData=
[
  ['greeting',['Greeting',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620a0819a4a3ceb1c5efdb8f8057db415035',1,'DataType']]]
];
