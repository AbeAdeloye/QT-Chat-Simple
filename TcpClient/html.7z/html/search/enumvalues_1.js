var searchData=
[
  ['error',['Error',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620ae36b6a6ba9b78f330799515b1536c1cb',1,'DataType']]]
];
