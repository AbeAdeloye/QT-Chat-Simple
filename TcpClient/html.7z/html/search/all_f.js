var searchData=
[
  ['tryconnect',['tryConnect',['../class_connection.html#aceb89f1fcbbb7029fe08797a8dbe9b73',1,'Connection']]]
];
