var searchData=
[
  ['maxbuffersize',['MaxBufferSize',['../connection_8h.html#a97a33a33e5428e13cfa0eff5ba0e846f',1,'connection.h']]]
];
