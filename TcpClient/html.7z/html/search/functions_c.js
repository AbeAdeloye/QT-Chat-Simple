var searchData=
[
  ['sendgreetingmessage',['sendGreetingMessage',['../class_connection.html#af9c4d241f6845701c8ea393ee59e06cb',1,'Connection']]],
  ['sendmessage',['sendMessage',['../class_connection.html#a4f5f635d3584775de12d009bbc5a6924',1,'Connection::sendMessage()'],['../class_main_window.html#a17c431be33f2b2b07f0994c549913b95',1,'MainWindow::sendMessage()']]],
  ['sendping',['sendPing',['../class_connection.html#a8f9b99bbea1f88aca4ffecc3efc9ce2f',1,'Connection']]],
  ['serverip',['serverIp',['../class_configs.html#a9cda9e0f301451ed7dcf2661966109c6',1,'Configs']]],
  ['serverisconnected',['serverIsConnected',['../class_connection.html#a748f39d7d43043639e1a5c3d60e36cb3',1,'Connection']]],
  ['serverport',['serverPort',['../class_configs.html#ac275f4b2f75f4a0da63057e7edc40167',1,'Configs']]],
  ['singleton',['Singleton',['../class_singleton.html#ab5f94d8f7b42c3fbc3a41335ffa583de',1,'Singleton']]],
  ['stoptryconnect',['stopTryConnect',['../class_connection.html#a1fd6f3bd9e2a039f88d6285bff257078',1,'Connection']]]
];
