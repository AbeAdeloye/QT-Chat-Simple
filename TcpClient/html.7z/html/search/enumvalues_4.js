var searchData=
[
  ['nick',['Nick',['../namespace_data_type.html#a9300cee69d320e2b7ef9c0cc4613f620aeae355ff7a3e6e1bac557639f9e0192e',1,'DataType']]]
];
